package com.example.education

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
